<div class="listing-titlebar">
    <div style="width:100%">
        <h6>Co nowego w aplikacji?</h6>
    </div>

</div>




<div class="listing-element">
    <div style="width:75%" class="listing-element__width75">
        <h6>BeautyPlany - aktualizacja 1.5.1</h6>
    </div>
    <div style="width:15%;" class="listing-element__width15">
        <h6>2023-02-21</h6>
    </div>
    <div style="width:10%;display:flex;flex-direction:row;" class="listing-element__width10">
        <div class="iconbutton">
            <i class="far fa-eye" onclick="location.href='{{url('functions/news_view')}}?id=13';" aria-hidden="true"></i>
        </div>
    </div>
</div>

<div class="listing-element">
    <div style="width:75%" class="listing-element__width75">
        <h6>Nowości w wersji 1.3</h6>
    </div>
    <div style="width:15%;" class="listing-element__width15">
        <h6>2022-09-19</h6>
    </div>
    <div style="width:10%;display:flex;flex-direction:row;" class="listing-element__width10">
        <div class="iconbutton">
            <i class="far fa-eye" onclick="location.href='{{url('functions/news_view')}}?id=12';" aria-hidden="true"></i>
        </div>
    </div>
</div>

<div class="listing-element">
    <div style="width:75%" class="listing-element__width75">
        <h6>Nowości w wersji 1.2! Już są!</h6>
    </div>
    <div style="width:15%;" class="listing-element__width15">
        <h6>2022-06-20</h6>
    </div>
    <div style="width:10%;display:flex;flex-direction:row;" class="listing-element__width10">
        <div class="iconbutton">
            <i class="far fa-eye" onclick="location.href='{{url('functions/news_view')}}?id=11';" aria-hidden="true"></i>
        </div>
    </div>
</div>



<div class="listing-element">
    <div style="width:75%" class="listing-element__width75">
        <h6>Aktualizacja aplikacji 1.1.0 już jest!</h6>
    </div>
    <div style="width:15%;" class="listing-element__width15">
        <h6>2022-04-26</h6>
    </div>
    <div style="width:10%;display:flex;flex-direction:row;" class="listing-element__width10">
        <div class="iconbutton">
            <i class="far fa-eye" onclick="location.href='{{url('functions/news_view')}}?id=9';" aria-hidden="true"></i>
        </div>
    </div>
</div>
