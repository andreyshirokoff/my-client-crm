<div class="listing-titlebar">
    <div style="width:28%">
        <h6>Nazwa zabiegu</h6>
    </div>
    <div style="width:44%">
        <h6>Imię i nazwisko klienta, notatka</h6>
    </div>
    <div style="width:15%;">
        <h6>Data</h6>
    </div>
    <div style="width:7%;">
        <h6>Karta</h6>
    </div>
    <div style="width:6%;">
        <h6>Akcje</h6>
    </div>
</div>
