

    <div class="listing-titlebar">
        <div style="width:40%;">
            <h6>Imię i Nazwisko</h6>
        </div>
        <div style="width:40%;">
            <h6>E-Mail</h6>
        </div>
        <div style="width:10%;">
            <h6>Tel</h6>
        </div>
        <div style="width:10%;display:flex;justify-content:flex-end;">
            <h6>Pokaż</h6>
        </div>
    </div>
    <livewire:client-index>
{{--    <div>--}}

{{--            <div class="listing-element">--}}
{{--                <div style="width:40%;">--}}
{{--                    <h6>Имя</h6>--}}
{{--                </div>--}}
{{--                <div style="width:40%;">--}}
{{--                    <h6>Имейл</h6>--}}
{{--                </div>--}}
{{--                <div style="width:10%;">--}}
{{--                    <h6>Телефон</h6>--}}
{{--                </div>--}}
{{--                <div style="width:10%;display:flex;justify-content:flex-end;" class="width-10">--}}
{{--                    <h6>Pokaż</h6>--}}
{{--                </div>--}}
{{--            </div>--}}

{{--        <div class="pagination-wrap mt-3"></div>--}}



{{--    </div>--}}

{{--    <div class="listing-element">--}}
{{--        <div style="width:40%;">--}}
{{--            <h6>Imię i Nazwisko</h6>--}}
{{--        </div>--}}
{{--        <div style="width:40%;">--}}
{{--            <h6>E-Mail</h6>--}}
{{--        </div>--}}
{{--        <div style="width:10%;">--}}
{{--            <h6>Tel</h6>--}}
{{--        </div>--}}
{{--        <div style="width:10%;display:flex;justify-content:flex-end;" class="width-10">--}}
{{--            <h6>Pokaż</h6>--}}
{{--        </div>--}}
{{--    </div>--}}


    <!-- Wczytanie klientów z bazy i ich listing -->

{{--    <div class="pagination-wrap mt-3">--}}



{{--    </div>--}}
    <!-- Wrzucenie footera -->
    <!--Beauty plany start -->
{{--    <script src="/functions/beautyplans/lib/jquery-3.6.2.min.js"></script>--}}
    <!--script to deal with ajax-->
    <script src="/functions/beautyplans/assets/js/beautyplans.js"></script>
    <!--additional css-->
{{--    <link rel="stylesheet" href="/functions/beautyplans/assets/css/beautyplans.css">--}}
{{--    <script src="/lib/select2/js/select2.min.js"></script>--}}
    <script>
        $(document).ready(function() {
            $('.area_choose.select2').select2();
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>




</div>
