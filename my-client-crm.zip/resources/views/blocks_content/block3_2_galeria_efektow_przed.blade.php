<div>
    <div class="listing-titlebar" style="margin-top:10px;">
        <div style="width:40%">

        </div>
        <div style="width:60%" class="sec-div">

        </div>
    </div>
    <div class="listing-element row-with-input">
        <div style="width:100%;">
            Zobacz lub utwórz dla tego klienta galerię efektów przed i po wykonaniu zabiegów. Zdjęcia do galerii dodawane są z poprzednio wykonanych zabiegów
        </div>
    </div>
    <div class="listing-actionbar">
        <a href=""><button type="button" class="btn1" style="margin-left:10px;"><i class="fa-solid fa-folder-open" style="color:white;margin-right:7px" aria-hidden="true"></i> Otwórz</button></a>
    </div>
</div>
