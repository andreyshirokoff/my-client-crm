<div>
        <div class="listing-titlebar" style="margin-top:10px;">
            <div style="width:40%">

            </div>
            <div style="width:60%" class="sec-div">

            </div>
        </div>
        <div class="listing-element row-with-input">
            <div style="width:100%;">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus eligendi eos et exercitationem necessitatibus optio perferendis, placeat quaerat quis suscipit. Dolorem dolores, dolorum eius illum molestias qui sunt veniam voluptate!
            </div>
        </div>
</div>
