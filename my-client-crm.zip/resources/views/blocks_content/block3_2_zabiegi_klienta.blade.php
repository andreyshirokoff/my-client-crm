<livewire:client-procedure-index/>
