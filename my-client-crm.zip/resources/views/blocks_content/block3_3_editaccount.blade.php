<livewire:edit-account-index/>


{{--<form action="editaccount-save.php" method="post">--}}

{{--    <div class="listing-titlebar input-element" style="margin-top:10px;">--}}
{{--        <div style="width:40%">--}}
{{--            <h6>Dostępne opcje</h6>--}}
{{--        </div>--}}
{{--        <div style="width:60%">--}}
{{--            <h6>Dane do zmiany</h6>--}}
{{--        </div>--}}
{{--    </div>--}}

{{--    <div class="listing-element input-element">--}}
{{--        <div style="width:40%;">--}}
{{--            Imię--}}
{{--        </div>--}}
{{--        <div style="width:60%;">--}}
{{--            <input type="text" name="imie" class="formularz" required="" value="Test">--}}
{{--        </div>--}}
{{--    </div>--}}

{{--    <div class="listing-element input-element">--}}
{{--        <div style="width:40%;">--}}
{{--            Nazwisko--}}
{{--        </div>--}}
{{--        <div style="width:60%;">--}}
{{--            <input type="text" name="nazwisko" class="formularz" required="" value="Test">--}}
{{--        </div>--}}
{{--    </div>--}}



{{--    <div class="listing-element input-element">--}}
{{--        <div style="width:40%;">--}}
{{--            Nr. Telefonu--}}
{{--        </div>--}}
{{--        <div style="width:60%;">--}}
{{--            <input type="tel" name="tel" class="formularz" pattern="^[0-9]{9}$" required="" value="323232323">--}}
{{--        </div>--}}
{{--    </div>--}}

{{--    <div class="listing-actionbar">--}}
{{--        <button type="submit" class="btn1"><i class="fas fa-check-circle" aria-hidden="true"></i> Ustaw zdjęcie</button>--}}
{{--    </div>--}}


{{--</form>--}}
