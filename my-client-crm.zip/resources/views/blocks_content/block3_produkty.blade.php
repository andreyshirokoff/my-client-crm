
<div class="listing-titlebar">
    <div style="width:10%">
    </div>
    <div style="width:40%">
        <h6>Nazwa produktu</h6>
    </div>
    <div style="width:15%">
        <h6>Cena</h6>
    </div>
    <div style="width:15%">
        <h6>Wystarcza na</h6>
    </div>
    <div style="width:20%">
    </div>
</div>
<!-- Wczytanie zabiegów z bazy i ich listing -->
<div class="listing-ending"></div>
<div class="listing-actionbar">
    <button type="button" onclick="location.href='{{url('functions/product_create')}}'" class="btn1"><i class="fas fa-plus-circle" aria-hidden="true"></i> Dodaj produkt</button>
</div>



