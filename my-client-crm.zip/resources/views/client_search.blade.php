@extends('layout.app')

@section('content')
    <livewire:client-index>
@endsection
