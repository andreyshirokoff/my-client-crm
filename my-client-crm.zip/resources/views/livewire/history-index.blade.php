
<div class="boxinbox-inside">

    <div style="display: flex; flex-direction: row; min-height: 100px; align-items: center;" class="pac-body-2">

        <div style="width: 15%; display: flex; flex-direction: row; justify-content:flex-start; align-items: center;">
            <i class="far fa-envelope-open" style="font-size:65px;" aria-hidden="true"></i>
            <!--<span class="icona-bc" style="width:75px; height:75px; background-size:75px 75px;background-position: center;"></span>-->
        </div>

        <div style="width: 25%;margin-left:10px;">
            <span>Pozostało Ci jeszcze:</span><br>
            <h3>10 smsów</h3>
        </div>
        <div style="width: 60%;margin-left:10px;">
            <span>Aby zwiększyć ilość sms - możesz kupić dowolny pakiet przez</span><br>
            <span>zakładkę Moje konto na stronie www.MyClient.pl.</span><br>
            <span><b>Doładowanie smsów znajduje się pod przedłużeniem konta.</b></span>
        </div>


    </div>

</div>
<div class="listing-titlebar" style="margin-top:10px;flex-direction:column;">
    <h3 style="width:100%;margin-bottom:30px;">Ostatnie 10 wysłanych smsów:</h3>
    <div style="display:flex;flex-direction:row;width:100%;" class="pac-body">
        <div style="width:15%">
            <h6>Data</h6>
        </div>
        <div style="width:15%">
            <h6>Nr tel.</h6>
        </div>
        <div style="width:15%">
            <h6>Ilość sms</h6>
        </div>
        <div style="width:55%">
            <h6>Typ sms</h6>
        </div>
    </div>
</div>
@foreach($infoGroup as $item)
<div class="listing-element" style="margin-top:10px;flex-direction:column;">
    <div style="display:flex;flex-direction:row;width:100%;" class="pac-body">
        <div style="width:15%">
            <h6>{{$item->date}}</h6>
        </div>
        <div style="width:15%">
            <h6>{{$item->phone}}</h6>
        </div>
        <div style="width:15%">
            <h6>{{$item->sms_count}}</h6>
        </div>
        <div style="width:55%">
            <h6>{{$item->type}}</h6>
        </div>
    </div>
</div>
@endforeach


<div class="listing-ending"></div>










